import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private httpClient: HttpClient) {
  }

  getAccountsList(): Observable<any> {
    return this.httpClient.get<any>('http://localhost:9000/api/users');
  }

  create(username:string, email:string, password:string, role:string): Observable<any> {
    return this.httpClient.post('http://localhost:9000/api/auth/signup', {
      username:username,
      email:email,
      password:password,
      role:[role]
    });
  }

  deleteAccount(loginId: String): Observable<void> {
    return this.httpClient.delete<void>('http://localhost:9000/api/users/delete/' + loginId);
  }

  getAccount(loginId: String): Observable<any> {
    return this.httpClient.get<any>('http://localhost:9000/api/users/' + loginId);
  }

  updateAccount(id:string, username:string, email:string, password:string, role:string): Observable<any> {
    return this.httpClient.put('http://localhost:9000/api/users/update', {
      id:id,
      username:username,
      email:email,
      password:password,
      role:[role]
    });
  }

  login(username:string , password:string){
    return this.httpClient.post<any>("http://localhost:9000/api/auth/signin",{
      username:username,password:password
    })

  }



}
