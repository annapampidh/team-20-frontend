import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class ApplicationService {

  constructor(private httpClient: HttpClient) {
  }

  getApplicationsList(): Observable<any> {
    return this.httpClient.get<any>('http://localhost:9000/api/application');
  }


  approveApplication(application_id:string): Observable<any> {
    return this.httpClient.post<any>('http://localhost:9000/api/application/setstatus/' + application_id, {
      status:'APPROVED'
    });
  }

  declineApplication(application_id:string): Observable<any> {
    return this.httpClient.post<any>('http://localhost:9000/api/application/setstatus/' + application_id, {
      status:'DECLINED'
    });
  }

  createApplication(politis:any, iatros:any, family_details:string,status:string): Observable<any> {
    return this.httpClient.post<any>('http://localhost:9000/api/application/newapplication',  {
      politis:politis,
      iatros:iatros,
      family_details:family_details,
      status: status
    });
  }



}
