import {Component, OnInit} from '@angular/core';
import {MatTableDataSource} from "@angular/material/table";
import {AccountService} from "../../services/account.service";
import {ApplicationService} from "../../services/application.service";
import {StorageService} from "../../services/storage.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-application-create',
  templateUrl: './application-create.component.html',
  styleUrls: ['./application-create.component.css']
})
export class ApplicationCreateComponent implements OnInit {

  family_Status: string = '';

  iatroi:any[] =[];
  selectedIatros: string = '';
  allUsers: any[] =[];
  politis_username: string = '';

  constructor(private accountService: AccountService,
              private applicationService: ApplicationService,
              private storageService: StorageService,
              private router: Router) {
  }

  ngOnInit(): void {
    this.politis_username = this.storageService.getUserUsername();

    this.accountService.getAccountsList().subscribe((res: any) => {
        this.allUsers = res;

      this.iatroi = this.allUsers.filter(user =>
        user.roles && user.roles.length === 1 && user.roles[0].name === 'ROLE_IATROS'
      );

      }, error =>
      {
        console.log("error")
      }
    );
  }

  isDisabled() {
    if (this.selectedIatros === '' || this.family_Status==='') {
      return true;
    } else {
      return false;
    }
  }

  create() {
    this.accountService.getAccount(this.storageService.getUserId()).subscribe(resp_politis =>{
      this.accountService.getAccount(this.selectedIatros).subscribe(resp_iatros =>{
        this.applicationService.createApplication(resp_politis, resp_iatros, this.family_Status, "PENDING").subscribe(resp=> {
            this.router.navigate(["/application-list"])
        }, error => {console.log(error)});
      })

    })



  }

}
