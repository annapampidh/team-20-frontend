import {Component, OnInit, ViewChild} from '@angular/core';
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import {ApplicationService} from "../../services/application.service";
import {AccountService} from "../../services/account.service";
import {DialogComponent} from "../../sharing/dialog/dialog.component";
import {MatDialog} from "@angular/material/dialog";
import {StorageService} from "../../services/storage.service";

@Component({
  selector: 'app-application-list',
  templateUrl: './application-list.component.html',
  styleUrls: ['./application-list.component.css']
})
export class ApplicationListComponent implements OnInit{

  allApplications: any;

  applications =new MatTableDataSource<any>();
  displayedColumns: string[] = ['id', 'politis', 'iatros', 'familydetails', 'status', 'approve', 'decline'];

  pageIndex = 0;
  pageSizeOptions = [10, 20, 30];
  showFirstLastButtons = true;
  length = 0;
  pageSize = 10;
  userRole: string ='';
  username: string = '';

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private applicationService: ApplicationService,
              private accountService: AccountService,
              private storageService: StorageService,
              private dialog: MatDialog) {
  }

  ngOnInit() {
    this.userRole = this.storageService.getUserRole();
    this.username = this.storageService.getUserUsername();
    this.applicationService.getApplicationsList().subscribe((res: any) => {
        this.allApplications = res;
        this.length = res.length;
        this.applications = new MatTableDataSource<any>(this.allApplications.slice(0, this.pageSize));
      }, error =>
      {
        console.log("error")
      }
    );

  }

  paginatorChange(event: any): void {
    const startIndex = event.pageIndex * event.pageSize;
    const endIndex = startIndex + event.pageSize;
    this.applications = this.allApplications.slice(startIndex, endIndex);
  }

  approve(element:any) {
    const dialogConfirm= this.dialog.open(DialogComponent,
      {data: {message: 'Are you sure you want to approve the application?',button: 'Approve'}}
    );

    dialogConfirm.afterClosed().subscribe((response) => {

        if (!response) {
          return;
        } else

          this.applicationService.approveApplication(element.id).subscribe((resp: any) => {
              this.applicationService.getApplicationsList().subscribe((res: any) => {
                  this.allApplications = res;
                  this.length = res.length;
                  this.pageSize = 10;
                  this.pageIndex = 0;
                  this.applications = new MatTableDataSource<any>(this.allApplications.slice(0, this.pageSize));
                }, error =>
                {
                  console.log("error")
                }
              );
            }, error => {
              console.log(error)
            }
          );
      }
    )
  }

  decline(element:any) {
    const dialogConfirm= this.dialog.open(DialogComponent,
      {data: {message: 'Are you sure you want to decline the application?',button: 'Decline'}}
    );

    dialogConfirm.afterClosed().subscribe((response) => {

        if (!response) {
          return;
        } else

          this.applicationService.declineApplication(element.id).subscribe((resp: any) => {
              this.applicationService.getApplicationsList().subscribe((res: any) => {
                  this.allApplications = res;
                  this.length = res.length;
                  this.pageSize = 10;
                  this.pageIndex = 0;
                  this.applications = new MatTableDataSource<any>(this.allApplications.slice(0, this.pageSize));
                }, error =>
                {
                  console.log("error")
                }
              );
            }, error => {
              console.log(error)
            }
          );
      }
    )
  }

}
