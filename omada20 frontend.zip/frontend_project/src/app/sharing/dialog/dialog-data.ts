export interface  DialogData{
  message: string;
  button: string;
}
