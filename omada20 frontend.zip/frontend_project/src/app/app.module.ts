import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { AccountListComponent } from './account-management/account-list/account-list.component';
import { AccountCreateComponent } from './account-management/account-create/account-create.component';
import {MatCardModule} from "@angular/material/card";
import {RouterLink, RouterOutlet} from "@angular/router";
import {MatTableModule} from "@angular/material/table";
import {MatPaginatorModule} from "@angular/material/paginator";
import { HomepageComponent } from './homepage/homepage.component';
import {AppRoutingModule} from "./app-routing.module";
import { NavigationBarComponent } from './navigation-bar/navigation-bar.component';
import {HttpClientModule} from "@angular/common/http";
import {MatSnackBarModule} from "@angular/material/snack-bar";
import {MatDialogModule} from "@angular/material/dialog";
import {MatButtonModule} from "@angular/material/button";
import {MatIconModule} from "@angular/material/icon";
import {MatMenuModule} from "@angular/material/menu";
import {MatToolbarModule} from "@angular/material/toolbar";
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatInputModule} from "@angular/material/input";
import {MatSelectModule} from "@angular/material/select";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { DialogComponent } from './sharing/dialog/dialog.component';
import { AccountEditComponent } from './account-management/account-edit/account-edit.component';
import { ApplicationListComponent } from './application-management/application-list/application-list.component';
import { ApplicationCreateComponent } from './application-management/application-create/application-create.component';
import {httpInterceptorProviders} from "./services/http.interceptor";

@NgModule({
  declarations: [
    AppComponent,
    AccountListComponent,
    AccountCreateComponent,
    HomepageComponent,
    NavigationBarComponent,
    DialogComponent,
    AccountEditComponent,
    ApplicationListComponent,
    ApplicationCreateComponent,
  ],
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    MatCardModule,
    RouterLink,
    MatTableModule,
    MatPaginatorModule,
    RouterOutlet,
    AppRoutingModule,
    HttpClientModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCardModule,
    MatDialogModule,
    MatTableModule,
    MatSnackBarModule
  ],
  providers: [httpInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
