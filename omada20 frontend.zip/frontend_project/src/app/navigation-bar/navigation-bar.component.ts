import {Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";
import {AccountService} from "../services/account.service";
import {MatDialog, MatDialogConfig} from "@angular/material/dialog";
import {MatSnackBar} from "@angular/material/snack-bar";
import {AccountCreateComponent} from "../account-management/account-create/account-create.component";
import {StorageService} from "../services/storage.service";

@Component({
  selector: 'app-navigation-bar',
  templateUrl: './navigation-bar.component.html',
  styleUrls: ['./navigation-bar.component.css']
})
export class NavigationBarComponent implements OnInit {
  credentials = {username: '', password: ''};
  isLoggedIn = false;

  role: string = '';
  userToken!: any;


  constructor(private accountService: AccountService,
              private router: Router,
              private snackBar: MatSnackBar,
              private dialog: MatDialog,
              private storageService: StorageService
  ) {
  }

  ngOnInit(): void {
    if (this.storageService.isLoggedIn()) {
      this.isLoggedIn = true;
      this.role = this.storageService.getUserRole();
      this.userToken = this.storageService.getUser();
    }
  }

  login(): void {
    this.accountService.login(this.credentials.username, this.credentials.password).subscribe({
      next: response => {
        this.storageService.setSession(response.accessToken);
        delete response.accessToken;
        this.storageService.saveUser(response);
         this.isLoggedIn = true;
        this.role = this.storageService.getUserRole();
        this.userToken = this.storageService.getUser();
        this.router.navigate(['homepage']);
        this.snackBar.open(this.storageService.getUserUsername() + ' logged in with role '+this.storageService.getUserRole(), '', {
              duration: 2000,
            });


      },
      error: err => {
        this.snackBar.open('Wrong Credentials: Please try again', '', {
          duration: 2000,
        });
      }
    });
  }

  logout(): void {
    this.credentials.password = '';
    this.credentials.username = '';
    this.isLoggedIn = false;
    this.storageService.clean();
    this.role= '';
    this.router.navigate(['/homepage']);
  }

  register() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '300';
    dialogConfig.height = '500';
    const dialogRef = this.dialog.open(AccountCreateComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(type => {
      this.dialog.closeAll();
    });
  }



}
