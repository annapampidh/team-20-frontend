import {Component, OnInit, ViewChild} from '@angular/core';
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import {AccountService} from "../../services/account.service";
import {Router} from "@angular/router";
import {MatDialog} from "@angular/material/dialog";
import {DialogComponent} from "../../sharing/dialog/dialog.component";

@Component({
  selector: 'app-account-list',
  templateUrl: './account-list.component.html',
  styleUrls: ['./account-list.component.css']
})
export class AccountListComponent implements OnInit {

  allUsers: any;

  users =new MatTableDataSource<any>();
  deleteUser: boolean= false;
  displayedColumns: string[] = ['id', 'email', 'username', 'delete'];

  pageIndex = 0;
  pageSizeOptions = [10, 20, 30];
  showFirstLastButtons = true;
  length = 0;
  pageSize = 10;

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private accountService: AccountService,
              private router: Router,
              public dialog: MatDialog) {
  }


  ngOnInit() {
    this.accountService.getAccountsList().subscribe((res: any) => {
        this.allUsers = res;
        this.length = res.length;
        this.users = new MatTableDataSource<any>(this.allUsers.slice(0, this.pageSize));
      }, error =>
      {
        console.log("error")
      }
    );
  }

  delete(element:any) {

    const dialogConfirm= this.dialog.open(DialogComponent,
      {data: {message: 'Are you sure you want to delete the account?',button: 'Confirm'}}
    );

    dialogConfirm.afterClosed().subscribe((response) => {

        if (!response) {
          return;
        } else

          this.accountService.deleteAccount(element.id).subscribe((resp: any) => {
              this.accountService.getAccountsList().subscribe((res: any) => {
                  this.allUsers = res;
                  this.length = res.length;
                  this.pageSize = 10;
                  this.pageIndex = 0;
                  this.users = new MatTableDataSource<any>(this.allUsers.slice(0, this.pageSize));
                }, error =>
                {
                  console.log("error")
                }
              );
          }, error => {
            console.log(error)
          }
          );
      }
    )
  }


  paginatorChange(event: any): void {
    const startIndex = event.pageIndex * event.pageSize;
    const endIndex = startIndex + event.pageSize;
    this.users = this.allUsers.slice(startIndex, endIndex);
  }


}
