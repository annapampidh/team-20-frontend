import {Component, OnInit, Optional} from '@angular/core';
import {AccountService} from "../../services/account.service";
import {Router} from "@angular/router";
import {MatSnackBar} from "@angular/material/snack-bar";
import {StorageService} from "../../services/storage.service";
import {MatDialogRef} from "@angular/material/dialog";

@Component({
  selector: 'app-account-create',
  templateUrl: './account-create.component.html',
  styleUrls: ['./account-create.component.css']
})
export class AccountCreateComponent implements OnInit {
  username: string = '';
  email: string = '';
  newPassword!: string;
  confirmPassword!: string;
  roles:any[] =[];
  selectedRole: string = '';

  constructor(private accountService: AccountService,
              private router: Router,
              private snackBar: MatSnackBar,
              private storageService: StorageService,
              @Optional() private dialog?: MatDialogRef<AccountCreateComponent>) {
  }

  ngOnInit() {
    this.roles = [
      {value: 'ROLE_POLITIS', viewValue: 'POLITIS'},
      {value: 'ROLE_IATROS', viewValue: 'IATROS'},
    ];
  }

  create() {
    this.accountService.create(this.username, this.email, this.newPassword, this.selectedRole).subscribe((res: any) => {
        console.log(res)
      this.snackBar.open('Account has been created.', '', {
        duration: 2000,
      });
        if(this.storageService.getUserRole()==='ROLE_ADMIN'){
          this.router.navigate(['/account-list']);
        }else{
          this.router.navigate(['/homepage']);
          this.dialog?.close();
        }

      }, error => {
      this.snackBar.open('Something went wrong. Please try again.', '', {
        duration: 2000,
      });
      console.log(error)}
    )

  }

  passwordsDoNotMatch() {
    if (this.newPassword !== this.confirmPassword) {
      return true;
    } else {
      return false;
    }
  }

  isDisabled() {
    if (this.passwordsDoNotMatch() || this.newPassword === '' ||
      this.email === '' || this.newPassword === undefined || this.selectedRole ==='' || this.username==='') {
      return true;
    } else {
      return false;
    }
  }
}
