import {Component, OnInit} from '@angular/core';
import {AccountService} from "../../services/account.service";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-account-edit',
  templateUrl: './account-edit.component.html',
  styleUrls: ['./account-edit.component.css']
})
export class AccountEditComponent implements OnInit {
  username!: string ;
  email!: string ;
  newPassword!: string ;
  confirmPassword!: string;
  roles:any[] =[];
  selectedRole: string = '';
  id!: string;

  constructor(private accountService: AccountService,
              private router: Router,
              private activatedRoute: ActivatedRoute) {
  }

  ngOnInit() {
    this.roles = [
      {value: 'ROLE_POLITIS', viewValue: 'POLITIS'},
      {value: 'ROLE_IATROS', viewValue: 'IATROS'},
    ];

    const loginID= this.activatedRoute.snapshot.params['id'];
     this.accountService.getAccount(loginID).subscribe(resp=> {
       console.log(resp);
       this.id = resp.id;
       this.username = resp.username;
       this.email = resp.email;
       this.selectedRole = resp.roles[0].name;
       this.newPassword = '';
       this.confirmPassword = '';
     }, error => {
       console.log(error);
     });
  }

  passwordsDoNotMatch() {
    if (this.newPassword !== this.confirmPassword) {
      return true;
    } else {
      return false;
    }
  }

  isDisabled() {
    if (this.passwordsDoNotMatch() || this.newPassword === '' ||
      this.email === '' || this.newPassword === undefined || this.selectedRole ==='' || this.username==='') {
      return true;
    } else {
      return false;
    }
  }

  update() {
    this.accountService.updateAccount(this.id, this.username, this.email, this.newPassword, this.roles[0]).subscribe((res: any) => {
        console.log(res)
      this.router.navigate(["/account-list"])
      }, error => {console.log(error)}
    )

  }
}
