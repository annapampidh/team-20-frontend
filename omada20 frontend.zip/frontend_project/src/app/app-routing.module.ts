import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule, Routes} from "@angular/router";
import {HomepageComponent} from "./homepage/homepage.component";
import {AccountListComponent} from "./account-management/account-list/account-list.component";
import {AccountCreateComponent} from "./account-management/account-create/account-create.component";
import {AccountEditComponent} from "./account-management/account-edit/account-edit.component";
import {ApplicationListComponent} from "./application-management/application-list/application-list.component";
import {ApplicationCreateComponent} from "./application-management/application-create/application-create.component";



const routes: Routes = [

  {path: '', redirectTo: 'homepage', pathMatch: 'full'},
  {path: 'homepage', component: HomepageComponent},
  {path: 'account-list', component: AccountListComponent},
  {path: 'account-create', component: AccountCreateComponent},
  {path: 'account-list/account-edit/:id', component: AccountEditComponent},
  {path: 'application-list', component: ApplicationListComponent},
  {path: 'application-create', component: ApplicationCreateComponent},
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
