package org.backend.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "application")
public class Application {

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank
    @Size(max = 150)
    private String status;

    @NotBlank
    @Size(max = 200)
    private String family_details;

    @OneToOne
    @JoinColumn(name="politis_id")
    private User politis;

    @OneToOne
    @JoinColumn(name="iatros_id")
    private User iatros;

    public Application() {
    }

    public String getFamily_details() {
        return family_details;
    }

    public void setFamily_details(String family_details) {
        this.family_details = family_details;
    }

    public Application(User politis, User iatros, String family_details) {
        this.politis = politis;
        this.iatros = iatros;
        this.family_details = family_details;
    }

    public User getPolitis() {
        return politis;
    }

    public void setPolitis(User politis) {
        this.politis = politis;
    }

    public User getIatros() {
        return iatros;
    }

    public void setIatros(User iatros) {
        this.iatros = iatros;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "RequestForApproval{" +
                "id=" + id +
                ", politis=" + politis +
                ", iatros=" + iatros +
                ", status=" + status +
                ", family_details=" + family_details +
                '}';
    }
}
