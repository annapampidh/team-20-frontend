package org.backend.controller;

import org.backend.models.Role;
import org.backend.models.User;
import org.backend.payload.response.MessageResponse;
import org.backend.repositories.RoleRepository;
import org.backend.repositories.UserRepository;
import org.backend.services.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    BCryptPasswordEncoder encoder;
    private final UserDetailsServiceImpl userService;

    public UserController(UserDetailsServiceImpl userService) {
        this.userService = userService;
    }

    @GetMapping("")

    public List<User> allUsers() {
        return userService.all();
    }

    @GetMapping("/{id}")
    public User findById(@PathVariable int id) { return userService.findSpecificUserById(id); }

    @PutMapping("update")
    public ResponseEntity<?> updateUser( @RequestBody User userDTO) {
        userService.delete(userDTO.getId());

        User user = new User(userDTO.getUsername(),
                userDTO.getEmail(),
                encoder.encode(userDTO.getPassword()));

         Set<Role> roles = userDTO.getRoles();

        user.setRoles(roles);
        userRepository.save(user);

        return ResponseEntity.ok(new MessageResponse("Account updated successfully!"));
     }

    @DeleteMapping("delete/{id}")
//    @PreAuthorize("hasAuthority('admin')")
    public ResponseEntity<String> deleteUser(@PathVariable int id) {
        userService.delete(id);
        return ResponseEntity.noContent().build();
    }


}
