package org.backend.controller;


import org.backend.models.Application;
import org.backend.models.User;
import org.backend.services.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
@RequestMapping("/api/application")
public class ApplicationController {

    @Autowired
    private ApplicationService applicationService;

    @GetMapping("")
    public List<Application> getApplications() {
        return applicationService.getApplications();
    }

    @GetMapping("politis/{politis_id}")
    public List<Application> getPolitisApplications(@PathVariable Integer politis_id) {
        return applicationService.getApplicationByPolitisID(politis_id);
    }

    @GetMapping("iatros/{iatros_id}")
    public List<Application> getIatrosApplications(@PathVariable Integer iatros_id) {
        return applicationService.getApplicationByIatrosID(iatros_id);
    }

    @GetMapping("{application_id}")
    public Application getApplicationById(@PathVariable Integer application_id) {
            return applicationService.getApplicationById(application_id);
    }

    @DeleteMapping("deleteapplication/{application_id}")
    public void deleteApplicationById(@PathVariable Integer application_id) {
        applicationService.deleteApplication(application_id);
    }

    @PostMapping("newapplication")
    public void saveRequestForApproval(@RequestBody Application application) {


        applicationService.saveApplication(application);
    }

    @PostMapping("setstatus/{application_id}")
    public void setApplicationStatus(
            @PathVariable Integer application_id,
            @RequestBody Map<String, String> statusMap) {
        String status = statusMap.get("status");
        applicationService.setStatus(application_id, status);
    }

    @GetMapping("/getByStatus")
    public List<Application> getApplicationsByStatus(@RequestParam String status) {
        return applicationService.getApplicationsByStatus(status);
    }

}

