package org.backend.repositories;

import io.swagger.v3.oas.annotations.Hidden;
import org.backend.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

@Hidden
public interface RoleRepository extends JpaRepository<Role, Integer> {
    Optional<Role> findByName(String roleName);
}
