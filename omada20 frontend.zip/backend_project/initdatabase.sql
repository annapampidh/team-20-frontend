DROP TABLE IF EXISTS users;

CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY,
    email      VARCHAR(50),
    password   VARCHAR(50),
    username   VARCHAR(20)
);

INSERT INTO users (id, email, password, username)
VALUES (1, 'admin@admin.admin', '$2a$10$Mt9o/vbJI7FG8q3QuED.sOhAPqih70esYglmzy7CJ57oxpG7VyJoC', 'admin');

INSERT INTO users (id, email, password, username)
VALUES (2, 'politis1@politis.politis', '$2a$10$Mt9o/vbJI7FG8q3QuED.sOhAPqih70esYglmzy7CJ57oxpG7VyJoC', 'politis1');

INSERT INTO users (id, email, password, username)
VALUES (3, 'iatros1@iatros.iatros', '$2a$10$Mt9o/vbJI7FG8q3QuED.sOhAPqih70esYglmzy7CJ57oxpG7VyJoC', 'iatros1');

DROP TABLE IF EXISTS application;

CREATE TABLE IF NOT EXISTS application (
    id         INTEGER PRIMARY KEY,
    politis_id INTEGER NOT NULL,
    family_details VARCHAR(200),
    iatros_id  INTEGER NOT NULL,
    status     VARCHAR(20),
    FOREIGN KEY (politis_id) REFERENCES users(id),
    FOREIGN KEY (iatros_id) REFERENCES users(id)
);

INSERT INTO application (id, politis_id, family_details, iatros_id, status)
VALUES (1, 2, '23 eton, agamos, antras', 3, 'PENDING');

DROP TABLE IF EXISTS roles;

CREATE TABLE IF NOT EXISTS roles (
    id   INTEGER PRIMARY KEY,
    name VARCHAR(20)
);

INSERT INTO roles (id, name)
VALUES (1, 'ROLE_ADMIN');

INSERT INTO roles (id, name)
VALUES (2, 'ROLE_POLITIS');

INSERT INTO roles (id, name)
VALUES (3, 'ROLE_IATROS');

DROP TABLE IF EXISTS user_roles;

CREATE TABLE IF NOT EXISTS user_roles (
    user_id INTEGER NOT NULL,
    role_id INTEGER NOT NULL,
    PRIMARY KEY (user_id, role_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

INSERT INTO user_roles (user_id, role_id)
VALUES (1, 1);

INSERT INTO user_roles (user_id, role_id)
VALUES (2, 2);

INSERT INTO user_roles (user_id, role_id)
VALUES (3, 3);

PRAGMA foreign_keys = ON;